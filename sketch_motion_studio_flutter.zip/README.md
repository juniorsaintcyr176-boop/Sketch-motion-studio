# Sketch Motion Studio (Flutter prototype)

This Flutter project is a prototype for Sketch Motion Studio (Skemo).
Features:
- Canvas with basic drawing
- Side panels: brushes, layers, timeline placeholder
- Import PNG brushes (like ibisPaint X) via 'Importer pinceau (PNG)' action
- Export canvas as PNG

How to build:
1. Install Flutter SDK: https://flutter.dev/docs/get-started/install
2. From project root run: `flutter pub get`
3. Run on Android device/emulator: `flutter run` or `flutter build apk`

Notes:
- For production, handle permissions and Android manifest changes for file access.
- This prototype uses simple textured brushes via ImageShader.
