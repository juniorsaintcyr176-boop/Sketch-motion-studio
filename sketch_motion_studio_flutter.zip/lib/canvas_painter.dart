import 'dart:ui' as ui;
import 'dart:typed_data';
import 'dart:io';
import 'package:flutter/material.dart';
import 'brush_manager.dart';

class StrokePoint {
  final Offset point;
  final double pressure;
  StrokePoint(this.point, this.pressure);
}

class Stroke {
  final List<StrokePoint> points;
  final int brushIndex;
  final double size;
  final double opacity;
  Stroke(this.points, this.brushIndex, this.size, this.opacity);
}

class CanvasArea extends StatefulWidget {
  const CanvasArea({Key? key}) : super(key: key);
  @override
  State<CanvasArea> createState() => CanvasAreaState();
}

class CanvasAreaState extends State<CanvasArea> {
  List<Stroke> strokes = [];
  Stroke? current;
  ui.Image? cacheImage;

  @override
  Widget build(BuildContext context) {
    final brushManager = BrushManager.of(context);
    return GestureDetector(
      onPanStart: (details) {
        final b = brushManager.selectedBrush;
        current = Stroke([StrokePoint(details.localPosition, 1.0)], b.index, b.size, b.opacity);
        setState((){});
      },
      onPanUpdate: (details) {
        if (current != null) {
          current!.points.add(StrokePoint(details.localPosition, 1.0));
          setState((){});
        }
      },
      onPanEnd: (_) {
        if (current != null) {
          strokes.add(current!);
          current = null;
          setState((){});
        }
      },
      child: RepaintBoundary(
        child: CustomPaint(
          painter: _CanvasPainter(strokes: strokes, current: current, brushManager: brushManager),
          size: Size.infinite,
        ),
      ),
    );
  }

  Future<Uint8List?> exportPNG() async {
    final boundary = context.findRenderObject() as RenderRepaintBoundary?;
    if (boundary == null) return null;
    final img = await boundary.toImage(pixelRatio: 3.0);
    final bytes = await img.toByteData(format: ui.ImageByteFormat.png);
    return bytes?.buffer.asUint8List();
  }
}

class _CanvasPainter extends CustomPainter {
  final List<Stroke> strokes;
  final Stroke? current;
  final BrushManager brushManager;
  _CanvasPainter({required this.strokes, this.current, required this.brushManager});

  _CanvasPainter({required this.strokes, required this.current, required this.brushManager});
  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(Offset.zero & size, Paint()..color=Color(0xFF111111));
    for (final s in strokes) {
      _drawStroke(canvas, s);
    }
    if (current != null) {
      _drawStroke(canvas, current!);
    }
  }

  void _drawStroke(Canvas canvas, Stroke s) {
    final brush = brushManager.getBrush(s.brushIndex);
    if (brush.image == null) return;
    final paint = Paint();
    paint.isAntiAlias = true;
    paint.filterQuality = FilterQuality.high;
    paint.color = Colors.white.withOpacity(s.opacity);
    // draw points as textured circles along path
    for (int i=0;i<s.points.length;i++) {
      final p = s.points[i].point;
      final rect = Rect.fromCenter(center: p, width: s.size, height: s.size);
      paint.shader = ImageShader(brush.image!, TileMode.clamp, TileMode.clamp, Float64List.fromList([1,0,0,0,1,0,0,0,1]));
      canvas.drawRect(rect, paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}
