import 'dart:ui' as ui;
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'canvas_painter.dart';
import 'brush_manager.dart';

void main() {
  runApp(ChangeNotifierProvider(
    create: (_) => BrushManager(),
    child: const SketchMotionApp(),
  ));
}

class SketchMotionApp extends StatelessWidget {
  const SketchMotionApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Sketch Motion Studio',
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF111116),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final GlobalKey<CanvasAreaState> canvasKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    final brushManager = Provider.of<BrushManager>(context);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Sketch Motion Studio'),
        actions: [
          IconButton(
            icon: const Icon(Icons.add_photo_alternate),
            tooltip: 'Importer pinceau (PNG)',
            onPressed: () async {
              // pick file
              final result = await FilePicker.platform.pickFiles(
                type: FileType.custom,
                allowedExtensions: ['png'],
              );
              if (result != null && result.files.isNotEmpty) {
                final file = result.files.first;
                final bytes = file.bytes;
                String savedPath;
                if (bytes != null) {
                  // write to app data
                  final dir = await getApplicationDocumentsDirectory();
                  final brushesDir = Directory('${dir.path}/brushes');
                  if (!await brushesDir.exists()) await brushesDir.create(recursive: true);
                  savedPath = '${brushesDir.path}/${file.name}';
                  final savedFile = File(savedPath);
                  await savedFile.writeAsBytes(bytes);
                } else if (file.path != null) {
                  savedPath = file.path!;
                } else {
                  return;
                }
                await brushManager.addBrushFromPath(savedPath);
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Pinceau importé avec succès')));
              }
            },
          ),
          IconButton(
            icon: const Icon(Icons.save),
            tooltip: 'Exporter image',
            onPressed: () async {
              final png = await canvasKey.currentState?.exportPNG();
              if (png != null) {
                final dir = await getApplicationDocumentsDirectory();
                final out = File('${dir.path}/sketch_${DateTime.now().millisecondsSinceEpoch}.png');
                await out.writeAsBytes(png);
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Exporté: ${out.path}')));
              }
            },
          ),
        ],
      ),
      body: Row(
        children: [
          // Left panel: tools
          Container(
            width: 84,
            color: const Color(0x0AFFFFFF),
            child: Column(
              children: [
                IconButton(
                  icon: const Icon(Icons.brush),
                  onPressed: () {},
                ),
                IconButton(
                  icon: const Icon(Icons.layers),
                  onPressed: () {},
                ),
                const SizedBox(height: 16),
                Expanded(
                  child: ListView.builder(
                    itemCount: brushManager.brushes.length,
                    itemBuilder: (context, index) {
                      final b = brushManager.brushes[index];
                      return GestureDetector(
                        onTap: () { brushManager.selectIndex(index); },
                        child: Container(
                          margin: const EdgeInsets.all(8),
                          padding: const EdgeInsets.all(6),
                          decoration: BoxDecoration(
                            border: brushManager.selectedIndex == index ? Border.all(color: Colors.cyanAccent, width: 2) : null,
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Image.file(File(b.path), width: 48, height: 48, fit: BoxFit.contain),
                        ),
                      );
                    },
                  ),
                )
              ],
            ),
          ),
          // Canvas area
          Expanded(
            child: CanvasArea(key: canvasKey),
          ),
          // Right panel: layers & timeline simplified
          Container(
            width: 240,
            color: const Color(0x0AFFFFFF),
            child: Column(
              children: [
                const Padding(
                  padding: EdgeInsets.all(8.0),
                  child: Text('Calques', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                ),
                Expanded(
                  child: ListView(
                    children: [
                      ListTile(title: const Text('Calque 1'), trailing: Switch(value: true, onChanged: (_) {})),
                      ListTile(title: const Text('Calque 2'), trailing: Switch(value: false, onChanged: (_) {})),
                    ],
                  ),
                ),
                const Divider(),
                const Padding(
                  padding: EdgeInsets.all(8.0),
                  child: Text('Timeline (frames)', style: TextStyle(fontSize: 16)),
                ),
                Container(
                  height: 120,
                  child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    itemCount: 12,
                    itemBuilder: (context, i) => Container(
                      width: 80,
                      margin: const EdgeInsets.all(6),
                      color: Colors.black12,
                      child: Center(child: Text('F${i+1}')),
                    ),
                  ),
                )
              ],
            ),
          )
        ],
      ),
    );
  }
}
