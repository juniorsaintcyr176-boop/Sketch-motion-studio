import 'dart:ui' as ui;
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image/image.dart' as img;
import 'dart:typed_data';
import 'package:flutter/services.dart' show rootBundle;

class Brush {
  final String name;
  final String path;
  ui.Image? image;
  double size;
  double opacity;
  int index;
  Brush({required this.name, required this.path, required this.index, this.size=24, this.opacity=1.0});
}

class BrushManager extends ChangeNotifier {
  List<Brush> brushes = [];
  int selectedIndex = 0;

  BrushManager() {
    _loadDefaultBrush();
  }

  static BrushManager of(BuildContext context) => Provider.of<BrushManager>(context, listen: false);

  Brush get selectedBrush => brushes.isNotEmpty ? brushes[selectedIndex] : brushes[0];

  Future<void> _loadDefaultBrush() async {
    // copy default asset to temp and load
    final data = await rootBundle.load('assets/brushes/default_brush.png');
    final bytes = data.buffer.asUint8List();
    final tempDir = Directory.systemTemp;
    final f = File('${tempDir.path}/default_brush.png');
    await f.writeAsBytes(bytes);
    await addBrushFromPath(f.path, name: 'Default');
  }

  Future<void> addBrushFromPath(String path, {String? name}) async {
    final n = name ?? path.split('/').last;
    final b = Brush(name: n, path: path, index: brushes.length);
    brushes.add(b);
    await _loadImageForBrush(b);
    notifyListeners();
  }

  Future<void> _loadImageForBrush(Brush b) async {
    try {
      final bytes = await File(b.path).readAsBytes();
      final codec = await ui.instantiateImageCodec(bytes);
      final frame = await codec.getNextFrame();
      b.image = frame.image;
    } catch (e) {
      // fallback: create small circle
      final recorder = ui.PictureRecorder();
      final c = Canvas(recorder);
      final paint = Paint()..color = Colors.white;
      c.drawCircle(Offset(16,16), 12, paint);
      final pic = recorder.endRecording();
      final im = await pic.toImage(32,32);
      b.image = im;
    }
  }

  Brush getBrush(int index) => brushes[index];

  void selectIndex(int i) { selectedIndex = i; notifyListeners(); }
}
